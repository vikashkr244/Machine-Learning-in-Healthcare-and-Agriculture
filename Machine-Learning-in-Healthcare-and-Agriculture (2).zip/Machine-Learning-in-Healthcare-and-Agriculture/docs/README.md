# Documentation

- `project_overview.pdf` – High level description (add manually).
- `research_paper_sources/` – Papers, references.
- `model_reports/` – Detailed model summaries and experiment logs.

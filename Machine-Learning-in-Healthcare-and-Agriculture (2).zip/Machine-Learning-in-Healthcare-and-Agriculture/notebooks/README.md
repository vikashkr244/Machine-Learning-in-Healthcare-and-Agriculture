# Notebooks

Suggested notebooks:

- `healthcare_exploration.ipynb` – EDA on healthcare data.
- `agriculture_exploration.ipynb` – EDA on agriculture data.
- `healthcare_model_training.ipynb` – Step-by-step healthcare model building.
- `agriculture_model_training.ipynb` – Step-by-step agriculture model building.
- `model_evaluation.ipynb` – Comparing and visualising model performance.

"""Simple FastAPI app exposing healthcare and agriculture models.

Run with:
    uvicorn deployment.api.fastapi_app:app --reload
"""

from typing import List

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

from src.models.healthcare_model import load_healthcare_model
from src.models.agriculture_model import load_agriculture_model

app = FastAPI(title="Healthcare & Agriculture ML API")


class HealthcareFeatures(BaseModel):
    age: int
    bmi: float
    blood_pressure: int
    cholesterol: int
    smoker: int
    diabetic: int


class AgricultureFeatures(BaseModel):
    rainfall: float
    temperature: float
    soil_ph: float
    fertilizer: float
    pesticide: float


@app.get("/")
def read_root():
    return {"message": "Healthcare & Agriculture ML API is running."}


@app.post("/predict/healthcare")
def predict_healthcare(features: HealthcareFeatures):
    try:
        model = load_healthcare_model()
    except FileNotFoundError as e:
        raise HTTPException(status_code=500, detail=str(e))

    X = [[
        features.age,
        features.bmi,
        features.blood_pressure,
        features.cholesterol,
        features.smoker,
        features.diabetic,
    ]]
    prediction = int(model.predict(X)[0])
    return {"high_risk": prediction}


@app.post("/predict/agriculture")
def predict_agriculture(features: AgricultureFeatures):
    try:
        model = load_agriculture_model()
    except FileNotFoundError as e:
        raise HTTPException(status_code=500, detail=str(e))

    X = [[
        features.rainfall,
        features.temperature,
        features.soil_ph,
        features.fertilizer,
        features.pesticide,
    ]]
    prediction = float(model.predict(X)[0])
    return {"predicted_yield_ton_per_ha": prediction}

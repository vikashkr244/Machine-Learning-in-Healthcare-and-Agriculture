"""Streamlit web app for demo usage.

Run with:
    streamlit run deployment/webapp/app.py
"""

import streamlit as st
import numpy as np

from src.models.healthcare_model import load_healthcare_model
from src.models.agriculture_model import load_agriculture_model


st.set_page_config(page_title="Healthcare & Agriculture ML", layout="centered")

st.title("Machine Learning in Healthcare and Agriculture")

mode = st.sidebar.selectbox("Choose domain", ["Healthcare", "Agriculture"])

if mode == "Healthcare":
    st.header("Healthcare Risk Prediction")
    age = st.slider("Age", 18, 90, 45)
    bmi = st.slider("BMI", 15.0, 40.0, 26.0, 0.1)
    bp = st.slider("Blood Pressure (systolic)", 80, 200, 120)
    chol = st.slider("Cholesterol (mg/dL)", 100, 350, 200)
    smoker = st.selectbox("Smoker", ["No", "Yes"])
    diabetic = st.selectbox("Diabetic", ["No", "Yes"])

    if st.button("Predict risk"):
        try:
            model = load_healthcare_model()
            X = np.array([[
                age,
                bmi,
                bp,
                chol,
                1 if smoker == "Yes" else 0,
                1 if diabetic == "Yes" else 0,
            ]])
            pred = int(model.predict(X)[0])
            if pred == 1:
                st.error("High risk detected.")
            else:
                st.success("Low risk detected.")
        except FileNotFoundError as e:
            st.warning(str(e))
            st.info("Run the preprocessing and training scripts first.")

else:
    st.header("Agriculture Crop Yield Prediction")
    rainfall = st.slider("Rainfall (mm)", 200.0, 2000.0, 900.0, 10.0)
    temp = st.slider("Temperature (°C)", 10.0, 45.0, 26.0, 0.5)
    soil_ph = st.slider("Soil pH", 4.0, 9.0, 7.0, 0.1)
    fertilizer = st.slider("Fertilizer (kg/ha)", 0.0, 300.0, 120.0, 5.0)
    pesticide = st.slider("Pesticide (kg/ha)", 0.0, 30.0, 5.0, 1.0)

    if st.button("Predict yield"):
        try:
            model = load_agriculture_model()
            X = np.array([[
                rainfall,
                temp,
                soil_ph,
                fertilizer,
                pesticide,
            ]])
            pred = float(model.predict(X)[0])
            st.success(f"Predicted yield: {pred:.2f} ton/ha")
        except FileNotFoundError as e:
            st.warning(str(e))
            st.info("Run the preprocessing and training scripts first.")

# Data Folder

Structure:

- `healthcare/raw/` – Original healthcare data (CSV, Excel, etc.).
- `healthcare/cleaned/` – Cleaned healthcare data.
- `healthcare/processed/` – Final datasets ready for modeling.

- `agriculture/raw/` – Original agriculture data.
- `agriculture/cleaned/` – Cleaned agriculture data.
- `agriculture/processed/` – Final datasets for modeling.

- `external/` – Any external/open datasets or metadata.

> Note: Real datasets are not included. Use your own data in `raw/`.

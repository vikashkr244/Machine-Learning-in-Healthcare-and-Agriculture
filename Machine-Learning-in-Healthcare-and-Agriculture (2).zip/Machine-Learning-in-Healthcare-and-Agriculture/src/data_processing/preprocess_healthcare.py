"""Healthcare data preprocessing.

If no data exists in data/healthcare/raw, this script will generate
a small synthetic dataset for demonstration.

Run:
    python -m src.data_processing.preprocess_healthcare
"""

import pandas as pd
import numpy as np
from pathlib import Path
from src.utils.logger import get_logger
from src.utils.file_handler import ensure_dir

logger = get_logger(__name__)

BASE_DIR = Path(__file__).resolve().parents[2]
RAW_DIR = BASE_DIR / "data" / "healthcare" / "raw"
CLEANED_DIR = BASE_DIR / "data" / "healthcare" / "cleaned"
PROCESSED_DIR = BASE_DIR / "data" / "healthcare" / "processed"


def generate_synthetic_healthcare_data(n_samples: int = 500) -> pd.DataFrame:
    np.random.seed(42)
    age = np.random.randint(20, 80, size=n_samples)
    bmi = np.round(np.random.normal(27, 4, size=n_samples), 1)
    blood_pressure = np.random.randint(90, 180, size=n_samples)
    cholesterol = np.random.randint(150, 300, size=n_samples)
    smoker = np.random.binomial(1, 0.3, size=n_samples)
    diabetic = np.random.binomial(1, 0.2, size=n_samples)

    # Simple risk score formula
    risk_score = (
        0.02 * (age - 40)
        + 0.03 * (bmi - 25)
        + 0.01 * (blood_pressure - 120)
        + 0.01 * (cholesterol - 200)
        + 0.4 * smoker
        + 0.5 * diabetic
    )
    prob = 1 / (1 + np.exp(-risk_score))
    high_risk = (prob > 0.5).astype(int)

    df = pd.DataFrame(
        {
            "age": age,
            "bmi": bmi,
            "blood_pressure": blood_pressure,
            "cholesterol": cholesterol,
            "smoker": smoker,
            "diabetic": diabetic,
            "high_risk": high_risk,
        }
    )
    return df


def main():
    ensure_dir(RAW_DIR)
    ensure_dir(CLEANED_DIR)
    ensure_dir(PROCESSED_DIR)

    raw_files = list(RAW_DIR.glob("*.csv"))
    if raw_files:
        logger.info("Found raw healthcare data, loading %s", raw_files[0].name)
        df = pd.read_csv(raw_files[0])
    else:
        logger.info("No raw data found. Generating synthetic healthcare dataset...")
        df = generate_synthetic_healthcare_data()

    # Example cleaning: drop duplicates, fill missing
    df = df.drop_duplicates()
    df = df.fillna(df.median(numeric_only=True))

    cleaned_path = CLEANED_DIR / "healthcare_cleaned.csv"
    df.to_csv(cleaned_path, index=False)
    logger.info("Saved cleaned healthcare data to %s", cleaned_path)

    # For this simple example, processed == cleaned
    processed_path = PROCESSED_DIR / "healthcare_data.csv"
    df.to_csv(processed_path, index=False)
    logger.info("Saved processed healthcare data to %s", processed_path)


if __name__ == "__main__":
    main()

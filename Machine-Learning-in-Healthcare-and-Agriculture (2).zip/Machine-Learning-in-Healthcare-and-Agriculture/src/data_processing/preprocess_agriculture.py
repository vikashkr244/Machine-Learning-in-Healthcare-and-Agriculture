"""Agriculture data preprocessing.

If no data exists in data/agriculture/raw, this script will generate
a small synthetic dataset for demonstration.

Run:
    python -m src.data_processing.preprocess_agriculture
"""

import pandas as pd
import numpy as np
from pathlib import Path
from src.utils.logger import get_logger
from src.utils.file_handler import ensure_dir

logger = get_logger(__name__)

BASE_DIR = Path(__file__).resolve().parents[2]
RAW_DIR = BASE_DIR / "data" / "agriculture" / "raw"
CLEANED_DIR = BASE_DIR / "data" / "agriculture" / "cleaned"
PROCESSED_DIR = BASE_DIR / "data" / "agriculture" / "processed"


def generate_synthetic_agriculture_data(n_samples: int = 500) -> pd.DataFrame:
    np.random.seed(123)
    rainfall = np.random.uniform(500, 1500, size=n_samples)  # mm
    temperature = np.random.uniform(15, 35, size=n_samples)  # °C
    soil_ph = np.random.uniform(5.5, 8.0, size=n_samples)
    fertilizer = np.random.uniform(50, 250, size=n_samples)  # kg/ha
    pesticide = np.random.uniform(0, 20, size=n_samples)  # kg/ha

    # Simple crop yield formula
    yield_ton_per_ha = (
        0.005 * rainfall
        + 0.3 * temperature
        - 0.5 * (soil_ph - 7) ** 2
        + 0.02 * fertilizer
        - 0.01 * pesticide
        + np.random.normal(0, 3, size=n_samples)
    )

    df = pd.DataFrame(
        {
            "rainfall": rainfall,
            "temperature": temperature,
            "soil_ph": soil_ph,
            "fertilizer": fertilizer,
            "pesticide": pesticide,
            "yield_ton_per_ha": yield_ton_per_ha,
        }
    )
    return df


def main():
    ensure_dir(RAW_DIR)
    ensure_dir(CLEANED_DIR)
    ensure_dir(PROCESSED_DIR)

    raw_files = list(RAW_DIR.glob("*.csv"))
    if raw_files:
        logger.info("Found raw agriculture data, loading %s", raw_files[0].name)
        df = pd.read_csv(raw_files[0])
    else:
        logger.info("No raw data found. Generating synthetic agriculture dataset...")
        df = generate_synthetic_agriculture_data()

    df = df.drop_duplicates()
    df = df.fillna(df.median(numeric_only=True))

    cleaned_path = CLEANED_DIR / "agriculture_cleaned.csv"
    df.to_csv(cleaned_path, index=False)
    logger.info("Saved cleaned agriculture data to %s", cleaned_path)

    processed_path = PROCESSED_DIR / "agriculture_data.csv"
    df.to_csv(processed_path, index=False)
    logger.info("Saved processed agriculture data to %s", processed_path)


if __name__ == "__main__":
    main()

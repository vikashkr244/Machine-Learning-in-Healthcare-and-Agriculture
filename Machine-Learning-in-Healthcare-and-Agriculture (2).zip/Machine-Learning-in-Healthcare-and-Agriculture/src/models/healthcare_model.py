"""Healthcare model training and loading utilities."""

from pathlib import Path
from typing import Tuple

import joblib
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report

from src.utils.logger import get_logger
from src.utils.file_handler import ensure_dir

logger = get_logger(__name__)

BASE_DIR = Path(__file__).resolve().parents[2]
DATA_PATH = BASE_DIR / "data" / "healthcare" / "processed" / "healthcare_data.csv"
MODEL_DIR = ensure_dir(BASE_DIR / "models" / "healthcare")
RESULTS_DIR = ensure_dir(BASE_DIR / "results" / "healthcare")


def load_data() -> Tuple[pd.DataFrame, pd.Series]:
    df = pd.read_csv(DATA_PATH)
    X = df.drop(columns=["high_risk"])
    y = df["high_risk"]
    return X, y


def train_healthcare_model(test_size: float = 0.2, random_state: int = 42) -> Path:
    logger.info("Loading healthcare data from %s", DATA_PATH)
    X, y = load_data()

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state, stratify=y
    )

    model = LogisticRegression(max_iter=1000)
    model.fit(X_train, y_train)
    logger.info("Trained LogisticRegression model for healthcare data.")

    y_pred = model.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    report = classification_report(y_test, y_pred)

    logger.info("Healthcare model accuracy: %.4f", acc)

    # Save model
    model_path = MODEL_DIR / "best_model.pkl"
    joblib.dump(model, model_path)
    logger.info("Saved healthcare model to %s", model_path)

    # Save evaluation results
    (RESULTS_DIR / "accuracy_score.txt").write_text(f"Accuracy: {acc:.4f}\n")
    (RESULTS_DIR / "classification_report.txt").write_text(report)
    logger.info("Saved evaluation metrics to %s", RESULTS_DIR)

    return model_path


def load_healthcare_model() -> LogisticRegression:
    model_path = MODEL_DIR / "best_model.pkl"
    if not model_path.exists():
        raise FileNotFoundError(
            f"Healthcare model not found at {model_path}. Train it first."
        )
    return joblib.load(model_path)


if __name__ == "__main__":
    train_healthcare_model()

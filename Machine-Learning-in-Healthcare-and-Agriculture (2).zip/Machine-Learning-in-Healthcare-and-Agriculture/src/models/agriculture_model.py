"""Agriculture model training and loading utilities."""

from pathlib import Path
from typing import Tuple

import joblib
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score

from src.utils.logger import get_logger
from src.utils.file_handler import ensure_dir

logger = get_logger(__name__)

BASE_DIR = Path(__file__).resolve().parents[2]
DATA_PATH = BASE_DIR / "data" / "agriculture" / "processed" / "agriculture_data.csv"
MODEL_DIR = ensure_dir(BASE_DIR / "models" / "agriculture")
RESULTS_DIR = ensure_dir(BASE_DIR / "results" / "agriculture")


def load_data() -> Tuple[pd.DataFrame, pd.Series]:
    df = pd.read_csv(DATA_PATH)
    X = df.drop(columns=["yield_ton_per_ha"])
    y = df["yield_ton_per_ha"]
    return X, y


def train_agriculture_model(test_size: float = 0.2, random_state: int = 123) -> Path:
    logger.info("Loading agriculture data from %s", DATA_PATH)
    X, y = load_data()

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state
    )

    model = RandomForestRegressor(n_estimators=100, random_state=random_state)
    model.fit(X_train, y_train)
    logger.info("Trained RandomForestRegressor model for agriculture data.")

    y_pred = model.predict(X_test)
    rmse = mean_squared_error(y_test, y_pred, squared=False)
    r2 = r2_score(y_test, y_pred)

    logger.info("Agriculture model RMSE: %.4f, R2: %.4f", rmse, r2)

    # Save model
    model_path = MODEL_DIR / "best_model.pkl"
    joblib.dump(model, model_path)
    logger.info("Saved agriculture model to %s", model_path)

    # Save evaluation results
    (RESULTS_DIR / "evaluation_report.txt").write_text(
        f"RMSE: {rmse:.4f}\nR2: {r2:.4f}\n"
    )
    logger.info("Saved evaluation metrics to %s", RESULTS_DIR)

    return model_path


def load_agriculture_model() -> RandomForestRegressor:
    model_path = MODEL_DIR / "best_model.pkl"
    if not model_path.exists():
        raise FileNotFoundError(
            f"Agriculture model not found at {model_path}. Train it first."
        )
    return joblib.load(model_path)


if __name__ == "__main__":
    train_agriculture_model()

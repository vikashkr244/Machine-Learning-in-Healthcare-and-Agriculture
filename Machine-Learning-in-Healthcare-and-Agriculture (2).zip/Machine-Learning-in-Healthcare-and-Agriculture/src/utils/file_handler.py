from pathlib import Path
from typing import Union

def ensure_dir(path: Union[str, Path]) -> Path:
    """Ensure directory exists and return Path."""
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p

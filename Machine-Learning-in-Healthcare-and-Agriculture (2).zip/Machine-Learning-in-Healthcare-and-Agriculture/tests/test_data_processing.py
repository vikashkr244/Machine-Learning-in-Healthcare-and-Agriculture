from pathlib import Path

def test_healthcare_processed_exists():
    path = Path("data/healthcare/processed/healthcare_data.csv")
    # This test will pass once the preprocessing script has been run
    assert path.parent.exists()

def test_agriculture_processed_exists():
    path = Path("data/agriculture/processed/agriculture_data.csv")
    assert path.parent.exists()

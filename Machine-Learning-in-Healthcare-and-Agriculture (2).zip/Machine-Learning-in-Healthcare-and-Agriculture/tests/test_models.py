from pathlib import Path

def test_healthcare_model_dir():
    assert Path("models/healthcare").exists()

def test_agriculture_model_dir():
    assert Path("models/agriculture").exists()
